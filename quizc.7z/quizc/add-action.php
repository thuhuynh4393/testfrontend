<html>
<head>
    <meta http-equiv="content-type" content="text/html; charset=UTF-8" />
</head>
<body>
<?php
session_start();

require_once './connect.php';
$id = $_POST['id-ques'];
$diff = $_POST['difficult'];
$chap= $_POST['chap'];
$question = $_POST['question'];
$A = $_POST['A'];
$B = $_POST['B'];
$C = $_POST['C'];
$D = $_POST['D'];
$ans = $_POST['answer'];

//xử lý chuỗi
    //nếu có ký tự đặt biệt "<"
//$ques= str_ireplace(array("#include <","#include<"), "#include &lt", $question);
$A_ans = str_ireplace(array("#include <","#include<"), "#include &lt", $A);
$B_ans = str_ireplace(array("#include <","#include<"), "#include &lt", $B);
$C_ans= str_ireplace(array("#include <","#include<"), "#include &lt", $C);
$D_ans = str_ireplace(array("#include <","#include<"), "#include &lt", $D);


//Query Insert vao bảng cauhoi
$query_insertQuestion="INSERT INTO cauhoi VALUES (".$id.",".$diff.",'".$question."',".$chap.")";
//Insert vào bảng traloi
$query_insertA="INSERT INTO traloi VALUES (".$id.",'A','".$A_ans."')";
$query_insertB="INSERT INTO traloi VALUES (".$id.",'B','".$B_ans."')";
$query_insertC="INSERT INTO traloi VALUES (".$id.",'C','".$C_ans."')";
$query_insertD="INSERT INTO traloi VALUES (".$id.",'D','".$D_ans."')";
//Insert vào bảng dapan (ans)
$query_insertAnswer="INSERT INTO dapan VALUES (".$id.",'".$ans."')";


if ($conn->query($query_insertQuestion) === TRUE && 
       $conn->query($query_insertAnswer) ===TRUE && 
        $conn->query($query_insertA)===TRUE && 
        $conn->query($query_insertB)===TRUE && 
        $conn->query($query_insertC)===TRUE && 
        $conn->query($query_insertD)===TRUE  ) {
    echo "<script charset='UTF-8'>";
        echo "alert('Thêm câu hỏi thành công');";
        echo "location.href='add.php'; "; 
    echo "</script>";
} else {
    echo "Error: " . $query_insertAnswer . "<br>" . $conn->error;
}
?>
</body>
</html>