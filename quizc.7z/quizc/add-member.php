<html>
<head>
    <meta http-equiv="content-type" content="text/html; charset=UTF-8" />
</head>
<body>
<?php
           session_start();
           
           require_once './connect.php';
           
           
           //$_SESSION['userLogin']=FALSE;
           //$_SESSION['admin']=FALSE;
           $_SESSION['userErr']="";
            //------------------------------------
           $new_id=$_POST['new_id'];
           $new_pass=$_POST['new_pass'];
           $new_name = $_POST['new_name'];
           $new_email = $_POST['new_email'];
           $new_bomon = $_POST['new_bomon'];
           $new_sdt = $_POST['new_sdt'];
           

           //md5 pass
           $pass = md5($new_pass);
           
           $query = "Select mcb From canbo where mcb='".$new_id."'";
           $result = mysqli_query($conn, $query) or die("Lỗi sql Add member");           
          $query_email = "Select email From canbo where email='".$new_email."'";
           $result_email = mysqli_query($conn, $query_email) or die("Lỗi sql Add member");

           $rowcount=  mysqli_num_rows($result);
           $row_email= mysqli_num_rows($result_email);
           
           if($rowcount==0){ 
              if($row_email==0) {            
               $query_insert="INSERT INTO canbo VALUES ('".$new_id."','".$pass."','".$new_email."','".$new_name."','".$new_bomon."','".$new_sdt."')";
               if ($conn->query($query_insert)===TRUE) {
      				   echo "<script charset='UTF-8'>";
      				       echo "alert('Thêm người dùng thành công');";
      				       echo "location.href='user.php'; "; 
      				   echo "</script>";
    				   } 
              }else{
                header("location:user.php");
               $_SESSION['newEmailErr']="Email đã tồn tại";
              }
           }else {               
               header("location:user.php");
               $_SESSION['newIdErr']="Username đã tồn tại";
           }
?>
</body>
</html>

            