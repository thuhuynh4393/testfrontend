<?php
    session_start();
    $title = 'Thêm câu hỏi';
    include('./template/block/header.php');
?>

<body onbeforeunload="return stay()">

    <?php
        if($_SESSION['userLogin']==FALSE){
            header("location:login.php");
            }
        
    ?>
    <div class="header" id="header-edit">
        <div class="container">
            <h1>Thêm câu hỏi</h1>
            <p>Scroll Down</p>
            <img src="./template/Image/arrow-down_icon.png" width="50px" height="50px"></img>
        </div>
    </div>
    <?php include ('./template/block/nav.php');?>
    
    <div class="main">
    <!-------------FORM ADD - START --------->
        <div class="box" id="box-add">
                    
                <!-- Noi dung list de thi-->
                <div class="content-box">
                    <!--=========================Menu taskbar thêm xoa cap nhat-->
                    
                    <!-- add câu hỏi-->
                    <div id="add">
                        <form id="add-form" action="add-action.php" method="post">
                            <!-- Mã câu hỏi-->
                            <div class="row">
                                <p id="title">Mã câu hỏi</p>
                                <span>
                                    <?php
                                        require_once './connect.php';
                                        $query_maxid="Select Max(macauhoi) As MaxId From cauhoi";
                                        $result=  mysqli_query($conn, $query_maxid) or die("Lỗi truy vấn MAX ID". mysqli_error() . "<br/>");
                                        $max =  mysqli_fetch_row($result); 
                                        $maxid = $max['0']+1;
                                        echo "<input class='id' type='text' disabled='disable' value=".$maxid.">";
                                        echo "<input type='hidden' name='id-ques' value=".$maxid.">";    
                                    ?>
                                </span>
                            </div>
                            <!-- Mức độ-->
                            <div class="row">
                                <p id="title">Mức độ</p>
                                <span>
                                    <select name="difficult" required>
                                        <option value="">---</option>
                                        <option value="1">Khó</option>
                                        <option value="0">Dễ</option>
                                    </select>
                                </span>
                            </div>
                            <!-- Chương-->
                            <div class="row">
                                <p id="title">Chương</p>
                                <span>
                                    
                                    <select name='chap' required>
                                        <option value=''>---</option>
                                        <?php
                                        $query_chap="Select * From chap";
                                        $result_chap=  mysqli_query($conn, $query_chap) or die ("Lỗi truy vấn Chap".  mysqli_error()."<br/>");
                                        while ($row_chap = mysqli_fetch_array($result_chap)) {
                                            echo "<option value=".$row_chap['chap'].">".$row_chap['noidung']."</option>";}
                                        ?>
                                    </select>
                                </span>
                            </div>
                            <!-- Nội dung câu hỏi-->
                            <div class="row-1">
                                <p id="title">Nội Dung Câu Hỏi</p>
                                <div class="">
                                    <textarea id="ckeditor" name="question" class="" required rows="10" cols="80"></textarea>
                                </div>
                            </div>
                            <!-- Nội dung câu trả lời -->
                            <div class="row">
                                <p id="title">Câu trả lời A</p>
                                <span>
                                    <input type="radio" name="answer" value="A" required>A
                                    <textarea name="A" class="A" required></textarea>
                                </span>
                            </div>
                            <!-- Nội dung câu trả lời -->
                            <div class="row">
                                <p id="title">Câu trả lời B</p>
                                <span>
                                    <input type="radio" name="answer" value="B" required>B
                                    <textarea name="B" class="B" required></textarea>
                                </span>
                            </div>
                            <!-- Nội dung câu trả lời -->
                            <div class="row">
                                <p id="title">Câu trả lời C</p>
                                <span>
                                    <input type="radio" name="answer" value="C" required>C
                                    <textarea name="C" class="C" required></textarea>
                                </span>
                            </div>
                            <!-- Nội dung câu trả lời -->
                            <div class="row">
                                <p id="title">Câu trả lời D</p>
                                <span>
                                    <input type="radio" name="answer" value="D" required>D
                                    <textarea name="D" class="D" required></textarea>
                                </span>
                            </div>
                            
                            <input class="btn" type="submit" name="add" value="Thêm">
                        </form>
                    </div>
                </div>
        </div>


<!--<div class="footer-end"></div>-->
<script src="./template/ckeditor/ckeditor.js"></script>
<script>
    // Replace the <textarea id="editor1"> with a CKEditor
    // instance, using default configuration.
    CKEDITOR.replace('ckeditor');
</script>
</body>
</html>


