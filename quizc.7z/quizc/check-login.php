<?php
           session_start();
           
           require_once './connect.php';
           
           
           $_SESSION['userLogin']=FALSE;
           $_SESSION['admin']=FALSE;
           //$_SESSION['loginErr']="";
            //------------------------------------
           $user=$_POST['username'];
           $pass=$_POST['password'];
           
           //md5 pass
           $pass = md5($pass);
           echo "IN TEST USER PASS";
           echo $pass;
           echo $user;
           //echo md5($pass);
           
           $query_login = "Select * From canbo where mcb='".$user."' and pass='".$pass."'";
           //echo "<br>".$query_login;
           $result_login = mysqli_query($conn, $query_login) or die("Lỗi sql check-login");
           
            while ($row = mysqli_fetch_array($result_login)){
            
                $_SESSION['nameMember']=$row['hoten'];
            }
           $rowcount=  mysqli_num_rows($result_login);
           //echo $rowcount ;
           
           if($rowcount==0){
               header("location:login.php");
               $_SESSION['userLogin']=FALSE;
               $_SESSION['loginErr']="Thông tin đăng nhập sai";
           }else {
               $_SESSION['userLogin']=TRUE;
               if($user=='admin'){
                  $_SESSION['admin']=TRUE;
               }               
               $_SESSION['userName']=$user;
               header("location:update.php");
           }
            
           
    
    
    

    
    
  
   
    
    
    
    
   
    
    
    
    
    
