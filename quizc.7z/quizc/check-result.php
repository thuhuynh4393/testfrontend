<?php
// Start the session
		session_start();
		$index=1;
		$title = 'Xem kết quả';
		include ('./template/block/header.php');
		require_once './connect.php';
?>
<body>
		<!-- LOGO HEADER - Start-->
		<div class="header">
			<div id="animation">
						<div id="img" class="layer"></div>
						<div id="img1" class="layer"></div>
						<div id="img2" class="layer"></div>
						<div id="img3" class="layer"></div>
						<div id="img4" class="layer"></div>
						<div id="img5" class="layer"></div>
						<div id="img6" class="layer"></div>
						<div id="img7" class="layer"></div>   
						<div id="img8" class="layer"></div>
						<div id="img9" class="layer"></div>
						<div id="img10" class="layer"></div>
						<div id="img11" class="layer"></div>
						<div id="img12" class="layer"></div>
						<div class="container">
								<h1>Quiz C</h1>
								<p>BẮT ĐẦU LÀM BÀI KIỂM TRA</p>
								<a class="btn" href="quiz.php">Starts</a>
						</div>
				</div>   
		</div>
		<?php include ('./template/block/nav.php');?>
		<!-- LOGO HEADER - END-->    
		<!-- NOI DUNG - Start-->
		<div class="main">
				<div class="tinhdiem">
						<div class="tinhdiem-content">
								<?php
										$right_check= array();
										$cauhoi_check = array();
										// lấy câu hỏi và câu trả lời của thí sinh
										foreach ($_SESSION["your_answer"] as $key => $value) {
												$cauhoi_check[$key]=$value;
										}
										//echo "Câu hỏi của thí sinh";
										//print_r($cauhoi_check);
										
										foreach ($_SESSION["right_answer"] as $key => $value) {
												$right_check[$key]=$value;
										}
										//echo "Câu đúng";
										//print_r($right_check);

										// In câu hỏi, câu trả lời, và đúng hoặc sai
										foreach ($cauhoi_check as $key => $value) {
												$query_check="SELECT noidungcauhoi, noidung FROM cauhoi,traloi "
																. "WHERE cauhoi.macauhoi =".$key." and traloi.macauhoi=".$key." and matraloi='".$value."'"; 

												$result_check=  mysqli_query($conn,$query_check) or die("LOI TRUY van CHeck"). mysqli_error();

												//HIển thị trong box
												echo "<div class='box' id='box-result'>";
														echo "<div class='content-box'>";                            

																while ($row_check=  mysqli_fetch_array($result_check)){
																		if(count($right_check)==0) {
																				$comment_answer = "SAI";
																		}  elseif(array_key_exists($key, $right_check)) {
																				$comment_answer = "Đúng";
																		}  else {
																				$comment_answer = "Sai";
																		}
																		$query_correct = "SELECT noidung From traloi, dapan WHERE traloi.macauhoi=".$key." AND dapan.macauhoi=traloi.macauhoi AND dapan.matraloi =traloi.matraloi";
																		$rs_correct = mysqli_query($conn,$query_correct) or die("LOI TRUY van đáp án đúng"). mysqli_error();																																			
																		$correct = mysqli_fetch_assoc($rs_correct);
																		$row_check['noidungcauhoi'] = str_ireplace(array("#include <","#include<"), "#include &lt", $row_check['noidungcauhoi']);
																		

																		echo "<span class='result-question'><h3>Câu hỏi: </h3><pre>".$row_check['noidungcauhoi']."</pre></span>";
																		//lay tat ca cau tra loi cua cau hoi
																		$query_answer = "SELECT * From traloi WHERE macauhoi=".$key;
																		$rs_ans = mysqli_query($conn,$query_answer) or die("LOI TRUY Cau tra loi"). mysqli_error();
																		while ($row_ans=  mysqli_fetch_array($rs_ans)){
																			echo "<span class='result-question'><b>".$row_ans['matraloi'].".</b>  ".$row_ans['noidung']."</span></br>";

																		}
																		echo "<span class='result-answer'><h3>Đáp án đúng:</h3> ".$correct['noidung']."</span></br>";
																		echo "<span class='result-answer'><h3>Đáp án của bạn:</h3> ".$row_check['noidung']."</span>";
																		echo "<span class='result-comment'>Kết quả: ".$comment_answer."</span>";                  
																}

														echo "</div>";
												echo "</div>";
										}
								?>
								
									<a class="btn" id="back" href="result.php">Xem lại kết quả</a>
								
						</div>
				
				</div>

		</div>
		
		<!-- NOI DUNG - END-->
	<div class="footer">
			<?php include('./template/block/footer.php');?>
	</div>
	<?php include ('./template/block/animation.php'); ?>

</body>
</html>