<?php
require_once './inc/config.php';
$conn = mysqli_connect($host, $username, $password)  or die("Không kết nối CSDL");
mysqli_set_charset($conn,"utf8");
mysqli_select_db($conn, $database) or dir("Không chọn được DB" . mysqli_error());
