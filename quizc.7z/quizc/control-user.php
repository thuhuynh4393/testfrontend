<?php
    session_start();
    $title="Cập nhật người dùng";
    include ('./template/block/header.php');
    if($_SESSION['admin']==FALSE){
        header("location:login.php");
    }
?>
<body>
    <form action="control_user_submit.php" class="form-container" method="post" accept-charset="utf-8">        	
        <?php
            require_once './connect.php';
            $id = $_GET['user'];
            $query = "SELECT * From canbo Where mcb='".$id."'";
            $result= mysqli_query($conn, $query) or die("SQL USER ERROR");
            while ($row = mysqli_fetch_array($result)) {
            echo "<div class='form-title'><h2>".$row['mcb']."</h2></div>"
                ."<div class='form-title'>Username</div>"
                ."<input class='form-field' disabled='disable' type='text' value='".$row['mcb']."' placeholder=''>" 
                ."<input type='hidden' name='mcb' value='".$row['mcb']."' placeholder=''>" 
                ."<div class='form-title'>Họ tên</div>"
                ."<input class='form-field' type='text' name='hoten' value='".$row['hoten']."' placeholder=''>" 
                ."<div class='form-title'>Email</div>"   
                ."<input class='form-field' disabled='disable' type='text' name='email' value='".$row['email']."' placeholder=''>" 
                ."<div class='form-title'>Bộ môn</div>"    
                ."<input class='form-field' type='text' name='bomon' value='".$row['bomon']."' placeholder=''>" 
                ."<div class='form-title'>Số điện thoại</div>"    
                ."<input class='form-field' type='text' name='sdt' value='".$row['sdt']."' placeholder=''>" ;
            }
        ?>
        <div class="submit-container">
        <input  class="submit-button" type="submit" value="Lưu" style="margin-left: 150px">
        </div>
    </form>
</body>
</html>