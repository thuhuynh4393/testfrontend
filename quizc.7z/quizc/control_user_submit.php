<html>
<head>
    <meta http-equiv="content-type" content="text/html; charset=UTF-8" />
</head>
<body>
<?php    
    session_start();
    $mcb = $_POST['mcb'];
    $new_ht = $_POST['hoten'];
    $new_bomon = $_POST['bomon'];
    $new_sdt = $_POST['sdt'];
    require_once './connect.php';
    $query = "UPDATE canbo SET hoten='".$new_ht."' ,bomon='".$new_bomon."' ,sdt='".$new_sdt."' "
            . "Where mcb='".$mcb."'";
   //$result= mysqli_query($conn, $query) or die("SQL USER ERROR");
   if ($conn->query($query) === TRUE) {
    echo "<script charset='UTF-8'>";
        echo "alert('Cập nhật thông tin thành công');";
        echo "location.href='user.php'; "; 
    echo "</script>";
} else {
    echo "Error: " . $query_insertAnswer . "<br>" . $conn->error;
}
?>
</body>
</html>