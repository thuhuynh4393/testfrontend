<html>
<head>
    <meta http-equiv="content-type" content="text/html; charset=UTF-8" />
</head>
<body>
<?php
    session_start();
	require_once './connect.php';
	$user_del = $_GET['user_del'];
    $query_delUser ="Delete From canbo Where mcb='".$user_del."'";        
        
        if($conn->query($query_delUser) === TRUE){
            echo "<script charset='UTF-8'> ";
                echo "alert('Xóa Người dùng Thành công'); ";             
                echo "location.href='user.php'; "; 
            echo" </script>";
        }  else {
            echo "<script charset='UTF-8'> ";
                echo "alert('Xóa Không Thành công'); ";             
                echo "location.href='user.php'; "; 
            echo" </script>";

        }
?>
</body>
</html>