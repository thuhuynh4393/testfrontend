<!DOCTYPE html>
<?php
    session_start();
    $title = 'Quên mật khẩu';
    include('./template/block/header.php');
?>
<body>
<!-- LOGO HEADER - Start-->
    <div class="header">
        <div class="container">            
            <form action="getpass-action.php" method="post" id="getpass-form" onsubmit="return checklog()">
                <h5 class="title">Quên mật khẩu:</h5>
                <!-- Điền email-->                
                <div class="row" >
                    <p>Vui lòng nhập Email để lấy lại mật khẩu:</p>
                    <input id="us" type="email" name="email"  required/>                              
                </div>                
                <!-- SUBMIT-->
                <div class="row" id="submit" style="padding-bottom: 10px" >
                    <input   type="submit" value="Gửi"/><br/>
                </div>
                <div style="margin-left: 11px"><p id="text"></p></div>
            </form>
        </div>            
    </div>    
</body>
</html>

