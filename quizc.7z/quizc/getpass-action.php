﻿<html>
<head>
    <meta http-equiv="content-type" content="text/html; charset=UTF-8" />
</head>
<body>
<?php
session_start();
require_once './connect.php';
include_once ('./template/block/rand_pass.php');
//lay email tu co so du lieu
$email= $_POST['email'];
$query="Select mcb , email From canbo Where email='".$email."'";
$result_mail = mysqli_query($conn, $query) or die("Lỗi sql Email");
$row_mail = mysqli_fetch_array($result_mail);
$username = $row_mail['mcb'];
$rowcount=  mysqli_num_rows($result_mail);
if($rowcount==0){
    echo "Email của bạn không đúng trong cơ sở dữ liệu. Vui lòng kiểm tra lại";
}  else {
    $newPass = rand_pass(6);
    $string_body = "Bạn đã gửi yêu cầu đổi mật khẩu.\nUsername: ".$username." \nĐây là mật khẩu mới của bạn: ".$newPass."\n"
            . "Vui lòng truy cập vào: http://quizzc.xyz/ để đăng nhập lại.";
    //send mail
    require './PHPMailer/PHPMailerAutoload.php';
    $mailer = new PHPMailer();
    $mailer->CharSet = "UTF-8";
    $mailer->IsSMTP();
    $mailer->Host = 'ssl://smtp.gmail.com';
    $mailer->Port = 465; //can be 587
    $mailer->SMTPAuth = TRUE;
    $mailer->Username = 'quizzc.elcit@gmail.com';  
    $mailer->Password = 'bX29sDrP';  
    $mailer->From = 'quizzc.elcit@gmail.com';  
    $mailer->FromName = 'QUIZZ C'; 
    $mailer->Body = $string_body;
    $mailer->Subject = 'QUIZZ C';
    $mailer->AddAddress($email);
    if(!$mailer->Send())
    {
        echo "Message was not sent<br/ >";
        echo "Mailer Error: " . $mailer->ErrorInfo;
    }
    else
    {
        //cap nhat pass vào csdl
        $pass_update = md5($newPass);
        $update = "UPDATE canbo SET pass='".$pass_update."' WHERE email='".$email."'";
        if($conn->query($update)===TRUE){
        echo "<script charset='UTF-8'>";
            echo "alert('Mật khẩu của bạn đã được gửi đi vui lòng kiểm tra mail');";
            echo "location.href='update.php'; "; 
        echo "</script>";
        }else {
        echo "Error: " . $conn->error;
        }
    }

}  

?>
</body>
</html>