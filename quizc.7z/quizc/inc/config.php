<?php
$host="localhost";
$username="root";
$password="";
$database="tracnghiemltcb";