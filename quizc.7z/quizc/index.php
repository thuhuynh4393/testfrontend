<?php
    session_start();
    $index = 1;
    include ('./template/block/header.php');
?>
<body class="wrapper">
    <div class="header">
        <div id="animation">
            <div id="img" class="layer"></div>
            <div id="img1" class="layer"></div>
            <div id="img2" class="layer"></div>
            <div id="img3" class="layer"></div>
            <div id="img4" class="layer"></div>
            <div id="img5" class="layer"></div>
            <div id="img7" class="layer"></div>   
            <div id="img8" class="layer"></div>
            <div id="img9" class="layer"></div>
            <div id="img10" class="layer"></div>
            <div class="container">
                <h1>Quiz C</h1>
                <p>BẮT ĐẦU LÀM BÀI KIỂM TRA</p>
                <a class="btn" href="quiz.php">Starts</a>
            </div>
        </div>        
    </div>
    <?php include ('./template/block/nav.php'); ?>
    <div class="main">
        <?php include ('./template/block/main.php'); ?>
    </div>
    <div class="footer">
        <?php include ('./template/block/footer.php'); ?>        
    </div>
        <?php include ('./template/block/animation.php'); ?>
  </body>
</html>