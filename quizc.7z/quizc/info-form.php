<!DOCTYPE html>
<?php
    session_start();
    $title = 'Cập nhật tài khoản';
    include('./template/block/header.php');
?>
<body>

    <?php
        if($_SESSION['userLogin']==FALSE){
            header("location:login.php");
            }
        include ('./template/block/nav.php');
    ?>
    <div class="main">
        <div class="container">
            
            <!-------------FORM ADD - START --------->
            <div class="box" id="box-infomation">
                        
                    <!-- Noi dung list de thi-->
                    <div class="content-box">
                        <!--=========================Menu taskbar thêm xoa cap nhat-->
                        <form action="">
                            
                        </form>
                    </div>
                    
            </div>
            <!-------------FORM ADD - START --------->
        </div>
    </div>
    

    

</body>
</html>


