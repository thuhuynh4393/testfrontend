<!DOCTYPE html>
<?php
    session_start();
    $title="Đăng nhập";
    include ('./template/block/header.php');
?>
<body>
<!-- LOGO HEADER - Start-->
    <div class="header">
        <div class="container" id="login">
            <form action="check-login.php" autocomplete="false" method="post" id="login-form" onsubmit="return checklog()">
                <h2 class="title">Login</h2>                
                <div class="row" >
                    <p>Username:</p>
                    <input id="us" type="text" name="username"  required/>                              
                </div>
                <div class="row" >
                    <p>Password:</p>
                    <input type="password" name="password" required/>
                </div>
                <!--Thông báo sai thông tin đăng nhập-->
                <div class="row" id="error">
                    <p> 
                        <?php
                            if(isset($_SESSION['loginErr'])){
                                echo "* ".$_SESSION['loginErr']; 
                                unset($_SESSION['loginErr']);
                            }
                        ?>
                    </p>
                </div>
                <!-- Quen mat khau-->
                <a title="Click để lấy lại mật khẩu" href="forget-pass.php">Bạn Quên Mật Khẩu?</a>
                <!-- SUBMIT-->
                <div class="row" id="submit" style="padding-bottom: 10px" >
                    <input   type="submit" value="Login"/><br/>
                </div>
                <div style="margin-left: 11px"><p id="text"></p></div>
            </form>
        </div>
    </div>    
</body>    
</html>

