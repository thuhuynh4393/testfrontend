<?php 
    require_once './connect.php';
    session_start();
    $title = 'Thi Trắc Nghiệm';
    $num_ques = 0;
    $MAX_NUMBER = 10;
    $index = 1;
    include ('./template/block/header.php');
?>
<body <?php echo (isset($_POST['start'])?'onload="init()"':''); ?> >
    <div class="tracnghiem">       
        <div class="header">
            <div class="container">
            </div>
        </div>
        <?php include ('./template/block/nav.php'); ?>
        <!-- NOI DUNG - Start-->
        <div class="main">
            <div class="left">
                <div class="box" id="box-list">
                    <form name="num_ques" method="post">
                        <p>Chọn số câu hỏi mà bạn muốn test:</p>
                        <select id="number-question" name="numberQuestion" required>
                            <option value="" selected disabled="disabled">- Chọn gói câu hỏi -</option>
                            <?php 
                                if(isset($_POST['numberQuestion'])) $num_ques=$_POST['numberQuestion'];
                                for($i = 1; $i <= $MAX_NUMBER; $i++) {
                                    echo '<option '.(($num_ques==($i*5))?'selected':'').' value="'.($i*5).'">'.($i*5).' Câu</option>';
                                }
                            ?>                            
                        </select>                        
                        <input  type="submit" class="btn" name="start" value="Bắt Đầu">
                        <input id="txt" readonly="true" type="text" value="00:00" border="0" name="disp">
                    </form>
                </div>
            </div>
        
            <!-- RIGHT noi dung cot ben phai chua noi dung cau hoi de thi-->
            <div class ="right">
                <!--    Box Noi dung de thi -->                      
                <!-- Test -->

            <?php                    
                if(isset($_POST['start'])) {
                    $num_ques=$_POST['numberQuestion'];
                    $num_ques_easy=(int)(($num_ques*2)/3);
                    $num_ques_diff=$num_ques-$num_ques_easy;                    
                    $idx = 1;
                    //câu lệnh truy vấn
                    $query = "(SELECT * FROM cauhoi WHERE mucdo=1 order by rand() limit ".$num_ques_diff.") "
                            . "UNION (SELECT * FROM cauhoi WHERE mucdo=0 order by rand() limit ".$num_ques_easy.")" ;

                    $result = mysqli_query($conn,$query) or die("Lỗi truy vấn" . mysqli_error() . "<br/>");
                    // Hiển thị câu hỏi trắc nghiệm
                    echo "<form id='quiz' action='tinhdiem.php' method='post'>";
                        while ($row = mysqli_fetch_array($result)) {
                                echo "<div class='box' id='box-nddt'>"
                                    ."<div class='content-box'>"
                                        ."<div class='question'>     ";
                                            $row['noidungcauhoi'] = str_ireplace(array("#include <","#include<"), "#include &lt", $row['noidungcauhoi']);
                                            echo "<pre><span>".$idx.". </span>".$row['noidungcauhoi']."</pre>";
                                            $idx++;
                                        echo "</div>"
                                            ."<div class='answer'>";
                                                    $query_ans = "SELECT * FROM traloi WHERE macauhoi=".$row['macauhoi']." order by rand()";
                                                    $result_ans = mysqli_query($conn,$query_ans) or die("Lỗi truy vấn ans" . mysqli_error() . "<br/>");
                                                    while($row_ans = mysqli_fetch_array($result_ans)){                                                
                                                        echo "<span>"
                                                            ."<pre><label><input class='radio-1' type='radio' name=".$row_ans['macauhoi']." value=".$row_ans['matraloi']." required>".$row_ans['noidung']."</label></pre>"
                                                            ."</span>";                         

                                                   }
                                        echo "</div>"
                                        ."</div>"
                                    ."</div>";
                        }
                        echo "<input type='submit' class='btn' value='Nộp Bài'>"
                    ."</form>";
                }    
            ?>
            </div>
            <!-- xoa cac float-->
            <div class="clr"></div>
           
        </div>
    
    </div>
    <!-- NOI DUNG - END-->

</body>
</html>