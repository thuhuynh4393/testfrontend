<?php 
session_start();
  $index =1;
  $title = 'Kết quả';
  include ('./template/block/header.php');
  include('./template/block/nav.php');
?>
<body>
<div class="tinhdiem">


<?php 
  echo "<div class='box' id='box-tinhdiem'>"
                        ."<div class='content-box'>"
                          ."<div class='point-comment'>"
                                //tính điểm và nhận xét
                                ."<br>"
                                ."<span class='diem'><h1>Số câu đúng: ". $_SESSION['diem']." .</h1></span>"
                                ."<span class='diem'><h1>Số câu sai: ".$_SESSION['sai']."</h1></span>"
                                ."<br>"
                                ."<span class='diem'><h1>".$_SESSION['percent']."</h1></span>"
                                ."<br>"
                                
                                //."<span class='cmt'><h1>". $comment_chap." .</h1></span>"
                                ."<span class='cmt'><h1>Nội dung Sai:<h1><h3>". $_SESSION['commt_wrong']."</h3></span>"
                            ."</div>"
                            // --- chứa các button check result và Try Again
                            ."<div class='choosen'>"
                                //."<form action='check-result.php' method='post'>"
                                    ."<div class='check-result'>"
                                        ."<a class='btn' href='check-result.php'>Kiểm tra kết quả</button>"
                                    ."</div>"
                                //."</form>"                                
                                //."<form action='quiz.php' method='post'>"
                                    ."<div class='try-again'>"
                                            ."<a class='btn' href='quiz.php'>Test mới</a>"
                                    ."</div>"
                                //."</form>"
                            ."</div>"
                        ."</div>"
                    ."</div>";
 ?>


</div>
</body>
</html>
