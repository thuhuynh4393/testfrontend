<script>
        window.onload = function() {            
            var tl = new TimelineLite();                                
            tl.to("#img", 0.1, {opacity:1})
            .to("#img1", 0.5, {opacity:1})
            .to("#img2", 0.5, {opacity:1})
            .to("#img3", 2, {opacity:1})
            .to("#img4", 0.5, {opacity:1})
            .to("#img5", 0.5, {opacity:1})
            .to("#img7", 0.5, {opacity:1})
            .to("#img8", 2, {opacity:1})
            .to("#img9", 0.5, {opacity:1})
            .to("#img10", 0.5, {opacity:1})
            .to("#img11", 0.5, {opacity:1})

            .to("#img1", 0.5, {left: -500})
            .to("#img2", 0.5, {top: 54,left: -200})
            .to("#img3", 0.5, {left: -150})
            .to("#img4", 0.5, {scaleX: -1,top: -370})
            .to("#img5", 0.5, {left: -600,top: -450})
            .to("#img7", 0.5, {top : 0,left: 100})
            .to("#img8", 0.5, {scaleX: -1})
            .to("#img9", 0.5, {left: 100})
            .to("#img10", 0.5, {scaleX: -1,top: 250})
            .to("#img11", 0.5, {scaleX: -1})
            .to("#img4", 0.5, {top: 370})
            .to("#img1", 0.5, {opacity:0})
            .to("#img2", 0.5, {opacity:0})
            .to("#img3", 2, {opacity:0})
            .to("#img4", 0.5, {opacity:0})
            .to("#img5", 0.5, {opacity:0})
            .to("#img7", 0.5, {opacity:0})
            .to("#img8", 2, {opacity:0})
            .to("#img9", 0.5, {opacity:0})
            .to("#img10", 0.5, {opacity:0})
            .to("#img11", 0.5, {opacity:0});
            tl.eventCallback("onComplete", replay);
            function replay(){
               tl.restart();
            }
        }
</script>