<!DOCTYPE html>
<html>
<head>
	<link rel="icon" href="./template/Image/favicon.ico" type="image/x-icon" sizes="16x16">
	<link href="./template/css/reset.css" rel="stylesheet" type="text/css"/>
	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
	<title><?php echo (isset($title)?$title:'Trang Chủ');?></title>
	<link href="./template/css/style.css" rel="stylesheet" type="text/css"/>  
	<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/gsap/1.18.0/plugins/CSSPlugin.min.js"></script>
	<script type="text/javascript" src="./template/js/TweenLite.min.js"></script>
	<script src="http://html5shiv.googlecode.com/svn/trunk/html5.js"></script>
	<script src="./template/js/TimelineLite.min.js"></script>
	<script src="./template/js/javascript.js"></script>
</header>