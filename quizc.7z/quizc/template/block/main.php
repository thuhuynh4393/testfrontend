<div class="container">
    <img src="./template/Image/programming_c.png">
    <h2>Giới thiệu Ngôn ngữ lập trình C</h2>
    <p>Ngôn ngữ lập trình C &#500; là một ngôn ngữ mệnh lệnh được phát 
        triển từ đầu thập niên 1970 bởi Dennis Ritchie để dùng 
        trong hệ điều hành UNIX. Từ đó, ngôn ngữ này đã lan rộng ra 
        nhiều hệ điều hành khác và trở thành một những ngôn ngữ phổ 
        dụng nhất. C là ngôn ngữ rất có hiệu quả và được ưa chuộng 
        nhất để viết các phần mềm hệ thống, mặc dù nó cũng được dùng 
        cho việc viết các ứng dụng. Ngoài ra, C cũng thường được dùng làm phương tiện giảng dạy 
        trong khoa học máy tính mặc dù ngôn ngữ này không được thiết 
        kế dành cho người nhập môn.</p>
    <h2>Giới thiệu trang web</h2>
    <p>Với việc đưa ngôn ngữ lập trình C vào giảng dạy. Các bạn sinh viên cần được test về kiến thức của mình
    để có thể kiểm tra tự đánh giá và củng cố kiến thức. Nên trang web này cung cấp nguồn câu hỏi trắc nghiệm cho 
    các bạn</p>
</div>
<div class="jumbotron">
  <div class="container">
        <?php include ('./template/block/clock.php'); ?>
        <?php
            if(isset($_SESSION['userLogin']) && $_SESSION['userLogin']==TRUE){
                
                echo "<h2 style='margin-bottom: 25px;'>Logout</h2>";
                echo "<p style='margin-bottom: 25px;'>Đăng xuất</p>";
                echo "<a class='btn' href='logout.php'>Logout</a>";
            }  else {
                echo "<h2 style='margin-bottom: 25px;'>Login</h2>";
                echo "<p style='margin-bottom: 25px;'>Để cập nhật đề thi vui lòng đăng nhâp</p>";
                echo "<a class='btn' href='login.php'>Đăng nhập</a>";
                
            }
        ?>
  </div>
</div>