<div class="nav">
  <div class="container">
        <ul>
            <li><a href="index.php" class="active">Trang chủ</a></li>      
            <?php
                if(isset($index) && $index == 1) {
                    echo '<li><a href="https://elcit.ctu.edu.vn/">Elcit</a></li>'
                        .'<li><a href="http://www.ctu.edu.vn">CTU</a></li>'
                        .'<li><a href="https://www.google.com/">Google</a></li>';
                }
                if(isset($_SESSION['admin']) && $_SESSION['admin']){
                    echo '<li>
                            <a href="user.php" title="Quản lý người dùng">Quản lý người dùng</a>
                        </li>';
                }
                if(isset($_SESSION['userLogin']) && $_SESSION['userLogin']){
                    echo '<li><a href="#">Quản lý đề thi</a>'
                        .'<ul class="sub">'
                                .'<li><a href="add.php">Thêm</a>'
                                .'<li><a href="update.php">Cập nhật</a>'
                            .'</ul>'
                        .'</li>'                        
                        .'<li><a href="infomation.php" title="Tài Khoản">Chào: '.$_SESSION['nameMember'].'!</a>'
                            .'<ul class="sub">'
                                .'<li><a href="logout.php">Đăng xuất</a>'
                            .'</ul>'
                        .'</li>';
                } else {
                    echo '<li><a href="login.php">Đăng nhập</a></li>';
                }
            ?>
            
            
            
        </ul>
  </div>
</div>