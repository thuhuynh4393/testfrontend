<?php
function rand_pass($n) {
	$str = "ABCDEFGHIJKMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
	$rs = "";
	for ($i=0; $i < $n; $i++) { 
		$index = rand(0, strlen($str) - 1);
		$rs = $rs . $str[$index];
	}
	return $rs;
}