/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


function checklog(){
    var user=document.forms["login-form"]["username"].value;
    var pass=document.forms["login-form"]["password"].value;    
    if(user == null || pass==null || user=="" || pass==""){
        alert("Bạn chưa nhập Username hoặc Password");
        return false;
    }
    
}

function alertLogin(){
    alert("Thông tin đăng nhập sai");
}

function confirmDelete(){
    return confirm("Bạn chắc muốn xóa?!");
}

function confirmUpdate(){
    return confirm("Bạn chắc muốn sửa nội dung?!");
}

function stay(){
    return "Bạn Xác Nhận Rời Đi?";
}

// dong ho dem nguoc

    var mins
    var secs;


function cd() {
    var x = document.getElementById("number-question").selectedIndex;
    var p = document.getElementsByTagName("option")[x].value;
    mins = 1 * p; // change minutes here
    secs = 0 + s(":01"); // change seconds here (always add an additional second to your total)
    redo();
}

function m(obj) {
    for(var i = 0; i < obj.length; i++) {
        if(obj.substring(i, i + 1) == ":")
        break;
    }
    return(obj.substring(0, i));
}

function s(obj) {
    for(var i = 0; i < obj.length; i++) {
        if(obj.substring(i, i + 1) == ":")
        break;
    }
    return(obj.substring(i + 1, obj.length));
}

function dis(mins,secs) {
    var disp;
    if(mins <= 9) {
        disp = " 0";
    } else {
        disp = " ";
    }
    disp += mins + ":";
    if(secs <= 9) {
        disp += "0" + secs;
    } else {
        disp += secs;
    }
    return(disp);
}

function redo() {
    secs--;
    if(secs == -1) {
        secs = 59;
        mins--;
    }
    document.num_ques.disp.value = dis(mins,secs); 
    if((mins == 0) && (secs == 0)) {
        window.alert("Hết giờ. Nhấn Ok để nộp bài!"); 
        //window.location = "quiz.php" // 
        document.getElementById("quiz").submit();
    } else {
        cd = setTimeout("redo()",1000);
    }
}

function init() {
    document.getElementById("txt").style.visibility="visible";
  cd();
  
}

