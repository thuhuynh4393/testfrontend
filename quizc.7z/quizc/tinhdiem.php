<?php
  // Start the session
  session_start();
  $title = 'Tính Điểm';
  $index = 1;
  include ('./template/block/header.php');
  require_once './connect.php';
?>
<body>   
    <!-- NOI DUNG - Start-->
    <?php include ('./template/block/nav.php');?>
    <div class="main">
        <div class="tinhdiem">
            <div class="tinhdiem-content">
                <?php
                    $cauhoi= array(); //danh sách câu hỏi
                    $traloi = array(); //ds câu trả lời của thí sinh
                    $dapan = array(); //ds đáp án từ csdl
                    $wrong_chap = array(); //ds câu trả lời sai
                    $num_ques=0; //số câu hỏi
                    
                    //thêm các câu trả lời của thí sinh vào traloi, và lấy danh sách câu hỏi                   
                    foreach ($_POST as $key => $value) {
                        $traloi[$key]=$value;
                        $cauhoi[$key]=$key;
                        $num_ques=$num_ques+1;
                    }                
                                        
                    //chuỗi câu hỏi lưu để dùng cho truy vấn csdl vd $string_ques ="(3,4,9,10,0)"
                    $string_ques ="(";            
                    foreach ($cauhoi as $key => $value) {
                        $string_ques = $string_ques.$value.",";
                    }
                    $string_ques=$string_ques."0)";
                    
                    //truy vấn và lấy dữ liệu
                   $query_dapan = "SELECT * FROM dapan WHERE macauhoi in ".$string_ques;
                   $result_dapan = mysqli_query($conn,$query_dapan) or die("Lỗi truy vấn Đáp án" . mysqli_error() . "<br/>");
                   while ($row_dapan = mysqli_fetch_array($result_dapan)) {
                       //thêm đáp án vào mảng $dapan
                       $dapan[$row_dapan['macauhoi']]=$row_dapan['matraloi'];
                   }                 
                    
                   //--- tính số câu đúng trên hai mang traloi va dapan,trả về là một mảng gồm câu giống nhau(đúng)
                   $result_match = array_intersect_assoc($traloi, $dapan);
                                      
                   //gán biến session
                   $_SESSION["your_answer"]=$traloi;
                   $_SESSION["right_answer"]=$result_match;
                   
                   
                   
                   //--- tính số câu Sai trên hai mang traloi va dapan, trả về Mảng gồm các câu sai
                   $result_unmatch = array_diff_assoc($traloi, $dapan);
                   //echo "câu sai: ";
                   //print_r($result_unmatch);
                   
                   //chuỗi lưu câu hỏi sai lưu để dùng cho truy vấn csdl phần chap(chương) vd $wrong_ques ="(3,4,9,10,0)"
                    $wrong_ques ="(";            
                    foreach ($result_unmatch as $key => $value) {
                        $wrong_ques = $wrong_ques.$key.",";
                    }
                    $wrong_ques=$wrong_ques."0)";
                    
                    
                   //điểm,phần trăm
                   $diem =count($result_match);//điểm bằng số câu trả lời đúng
                   $sai=count($result_unmatch);
                   $_SESSION['diem']=$diem;
                   $_SESSION['sai']=$sai;
                   if($num_ques==0){
                    $percent=0;
                   }else{
                      $percent = ($diem*100)/$num_ques; 
                   }
                                     
                   $string_percent="Bạn đạt ".$percent."%";
                   
                   $_SESSION['percent'] = $string_percent;
                   //-----------khuyên phần nên học lại
                   //lấy chap sai
                   $query_chap="SELECT chap FROM cauhoi WHERE macauhoi in ".$wrong_ques;
                   $result_chap = mysqli_query($conn,$query_chap) or die("Lỗi query Chap") . mysqli_error();
                   while ($row_chap = mysqli_fetch_array($result_chap)) {
                       array_push($wrong_chap, $row_chap['chap']);
                    }
                   
                   //đếm số chap sai theo từng chap
                   $count_wrong_chap=array_count_values($wrong_chap);
                   $wrong="(";
                        foreach ($count_wrong_chap as $key => $value) {
                            $wrong= $wrong.$key.",";
                        }
                        $wrong=$wrong."0)";
                   
                   //tính số chap sai nhiều nhất
                   if(empty($count_wrong_chap)){
                       $max_sp=0;
                       $chap_max="(0)";
                   }  else {
                       $max_sp=array(max($count_wrong_chap));
                       $chap = array_intersect($count_wrong_chap, $max_sp);
                        $chap_max="(";
                        foreach ($chap as $key => $value) {
                            $chap_max= $chap_max.$key.",";
                        }
                        $chap_max=$chap_max."0)";
                   }
                   
                   
                   //echo "<br>Chap sai nhiều nhất: ".$chap_max;
                   
                   //lấy nội dung chap sai nhiều nhất
                   $comment_chap="Nội dung sai nhiều nhất: <br>";
                   $query_chap="SELECT * FROM chap WHERE chap in ".$chap_max;
                   $result_chap_cmt = mysqli_query($conn,$query_chap) or die("Lỗi query Chap max") . mysqli_error();
                   while ($row_chap = mysqli_fetch_array($result_chap_cmt)) {
                       $comment_chap = $comment_chap.$row_chap['noidung']."(".$chap[$row_chap['chap']].") ";
                    }
                   //lấy số câu sai theo từng nội dung
                    $commt_wrong = "";
                    $query="SELECT * FROM chap WHERE chap in ".$wrong;
                    $result_chap_wrong_cmt = mysqli_query($conn,$query) or die("Lỗi query Chap max") . mysqli_error();
                    while ($row_chap = mysqli_fetch_array($result_chap_wrong_cmt)) {
                        $commt_wrong = $commt_wrong.$row_chap['noidung']."(".$count_wrong_chap[$row_chap['chap']].")<br/> ";
                     }
                    $_SESSION['commt_wrong']=$commt_wrong;
                    
                   //-----------Box hiển thị điểm, comment
                    
                   echo "<div class='box' id='box-tinhdiem'>"
                        ."<div class='content-box'>"
                        .  "<h2>Hệ thống đã chấm kết quả</h2>"
                        .  '<a class="btn" id="xkq" href="result.php">Xem kết quả</a>'                            
                        ."</div>"
                    ."</div>";
                    
                ?>
      </div>
    </div>
    
  </div>

    
</body>
</html>