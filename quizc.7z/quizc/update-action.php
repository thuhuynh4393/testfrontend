<html>
<head>
    <meta http-equiv="content-type" content="text/html; charset=UTF-8" />
</head>
<body>
<?php

require_once './connect.php';
$id = $_POST['idUpdate'];
$diff = $_POST['difficult'];
$chap= $_POST['chap'];
$question = $_POST['questionUpdate'];
$A = $_POST['A'];
$B = $_POST['B'];
$C = $_POST['C'];
$D = $_POST['D'];
$correct = $_POST['answer'];


//xử lý chuỗi
    //nếu có ký tự đặt biệt "<"
//$ques= str_ireplace(array("#include <","#include<"), "#include &lt", $question);
$A_ans = str_ireplace(array("#include <","#include<"), "#include &lt", $A);
$B_ans = str_ireplace(array("#include <","#include<"), "#include &lt", $B);
$C_ans= str_ireplace(array("#include <","#include<"), "#include &lt", $C);
$D_ans = str_ireplace(array("#include <","#include<"), "#include &lt", $D);


//Query Update vao bảng cauhoi
$query_updateQuestion="UPDATE cauhoi SET mucdo=".$diff.", noidungcauhoi='".$question."',chap=".$chap." WHERE macauhoi=".$id;
//Insert vào bảng traloi
$query_updateA="UPDATE traloi SET noidung='".$A_ans."' WHERE macauhoi=".$id." AND matraloi='A'";
$query_updateB="UPDATE traloi SET noidung='".$B_ans."' WHERE macauhoi=".$id." AND matraloi='B'";
$query_updateC="UPDATE traloi SET noidung='".$C_ans."' WHERE macauhoi=".$id." AND matraloi='C'";
$query_updateD="UPDATE traloi SET noidung='".$D_ans."' WHERE macauhoi=".$id." AND matraloi='D'";
//Update vào bảng dapan (ans)
$query_updateAnswer="UPDATE dapan SET matraloi='".$correct."' WHERE macauhoi=".$id;


if ($conn->query($query_updateQuestion) === TRUE && 
       $conn->query($query_updateAnswer) ===TRUE && 
        $conn->query($query_updateA)===TRUE && 
        $conn->query($query_updateB)===TRUE && 
        $conn->query($query_updateC)===TRUE && 
        $conn->query($query_updateD)===TRUE  ) {
    echo "<script charset='UTF-8'>";
        echo "alert('Câu hỏi đã cập nhật thành công!');";
        echo "location.href='update.php'; "; 
    echo "</script>";
} else {
    echo "Error: " . $query_insertAnswer . "<br>" . $conn->error;
}

?>
</body>
</html>