<!DOCTYPE html>
<?php
    session_start();
    $title="Form sửa";
    include('./template/block/header.php');
?>
<body>
    <?php
        if($_SESSION['userLogin']==FALSE){
            header("location:login.php");
            }
        include('./template/block/nav.php');

    ?>     
    <div class="main">
    <!-------------FORM UPDate - START --------->
        <div class="box" id="box-update-form">
                <div class="content-box">
                    
                    <!-- add câu hỏi-->
                    <div >
                        <form id="update-form" action="update-action.php" method="post">
                            <!-- Mã câu hỏi-->
                            <div class="row">
                                <p id="title">Mã câu hỏi</p>
                                <span>
                                    <?php
                                        require_once './connect.php';
                                        $update_id=$_GET['update_id'];
                                        $sql_query="SELECT noidungcauhoi, chap FROM cauhoi WHERE macauhoi=".$update_id;
                                        $result =  mysqli_query($conn, $sql_query) or die("SQL DELETE.php ERROR: ".  mysqli_errno($conn));
                                        $row = mysqli_fetch_assoc($result);
                                    ?>
                                        <input class='id' type='text' disabled='disable' value="<?php echo $update_id?>" >
                                        <input type='hidden' name="idUpdate" value="<?php echo $update_id?>" >                                    
                                </span>
                            </div>
                            <!-- Mức độ-->
                            <div class="row">
                                <p id="title">Mức độ</p>
                                <span>
                                    <select name="difficult" required>
                                        <option value="">---</option>
                                        <option id="diff" value="1">Khó</option>
                                        <option id="easy" value="0">Dễ</option>
                                    </select>
                                </span>
                            </div>
                            <!-- Chương-->
                            <div class="row">
                                <p id="title">Chương</p>
                                <span>
                                    <select name="chap" required>
                                        <option value="">---</option>
                                        <option id="1" value="1">Cú pháp</option>
                                        <option id="2" value="2">Khai báo biến</option>
                                        <option id="3" value="3">Kiểu dữ liệu</option>
                                        <option id="4" value="4">Nhập/Xuất</option>
                                        <option id="5" value="5">Thư viện Hàm</option>
                                        <option id="6" value="6">Định nghĩa hàm</option>
                                        <option id="7" value="7">Truyền tham số</option>
                                        <option id="8" value="8">Gọi hàm</option>
                                        <option id="9" value="9">Cấu trúc rẽ nhánh</option>
                                        <option id="10" value="10">Cấu trúc lặp </option>
                                        <option id="11" value="11">Đệ quy </option>
                                        <option id="12" value="12">Con trỏ</option>
                                        <option id="13" value="13">Mảng</option>
                                        <option id="14" value="14">Chuỗi </option>
                                        <option id="15" value="15">Tập tin </option>
                                        <option id="16" value="16">Kiểu dữ liệu cấu trúc </option>
                                        <option id="17" value="17">Cấp phát động vùng nhớ</option>
                                        <option id="18" value="18">Chuyển đổi kiểu </option>
                                        <option id="19" value="19">Toán tử</option>                                            
                                    </select>
                                </span>
                            </div>
                            <!-- Nội dung câu hỏi-->
                            <div class="row-1">
                                <p id="title">Nội Dung Câu Hỏi</p>
                                <div class="">
                                    <textarea id="ckeditor" name="questionUpdate" class="" required rows="10" cols="80">
                                    <?php 
                                    //$row['noidungcauhoi'] = str_ireplace(array("#include <","#include<"), "#include &lt;", $row['noidungcauhoi']);
                                    echo $row['noidungcauhoi']; ?>
                                    </textarea>
                                </div>
                            </div>
                            <!-- Nội dung câu trả lời -->
                            <?php
                            $query="SELECT * FROM traloi WHERE macauhoi=".$update_id;
                            $result_update =  mysqli_query($conn, $query) or die("SQL UPDATE ERROR: ".  mysqli_errno($conn));
                               
                            while($row_update = mysqli_fetch_array($result_update)){                                
                                echo "<div class='row'>";
                                    echo "<p id='title'>Câu trả lời ".$row_update['matraloi']."</p>";                                    
                                    echo "<span>";
                                        echo "<input type='radio' name='answer' value='".$row_update['matraloi']."' required>".$row_update['matraloi'];
                                        echo "<textarea name='".$row_update['matraloi']."' "
                                                . "class='".$row_update['matraloi']."' required>".$row_update['noidung']."</textarea>";
                                    echo "</span>";
                                echo "</div>";
                            }
                            ?>
                            
                            <input class="btn" name="update" type="submit" value="Lưu cập nhật">
                        </form>
                    </div>
                </div>
        </div>
<script>        
     function myFunction($str,$tr) {
            document.getElementById($str).selected = "true";
            document.getElementById($tr).selected = "true";
        }
</script>
<script src="./template/ckeditor/ckeditor.js"></script>
<script>    
    CKEDITOR.replace('ckeditor');
</script>
</body>
</html>



