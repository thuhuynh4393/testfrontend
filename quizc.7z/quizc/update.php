<?php
    session_start();
    $title = 'Cập nhật đề thi';
    include('./template/block/header.php');
?>
<body >
    <?php
        if($_SESSION['userLogin']==FALSE){
          header("location:login.php");
        }
    ?>
    <div class="header" id="header-edit">
        <div class="container">
            <h1><?php if(isset($title)) echo $title; ?></h1>
            <p>Scroll Down</p>
            <img src="./template/Image/arrow-down_icon.png" width="50px" height="50px"></img>
        </div>
    </div>
    
    <?php include('./template/block/nav.php'); ?>
    
    <div class="main">
    <!-------------FORM UPDATE - START --------->
        <div class="box" id="box-update">
                    
                <!-- Noi dung list de thi-->        
                <div class="content-box">
                    
                    <!-- delete câu hỏi-->
                    <div class="question-item">
                        <?php
                            require_once './connect.php';
                            $query_del="SELECT cauhoi.macauhoi,cauhoi.noidungcauhoi,traloi.noidung "
                                        . "FROM cauhoi,dapan,traloi "
                                        . "WHERE cauhoi.macauhoi=dapan.macauhoi and "
                                        . "dapan.matraloi=traloi.matraloi and cauhoi.macauhoi=traloi.macauhoi ";
                            $result_del= mysqli_query($conn, $query_del) or die("SQL DELETE.php ERROR");
                            while ($row = mysqli_fetch_array($result_del)) {
                                echo "<div class='question-item'><div class='del-row'>";
                                        echo "<div class='id'>";
                                            echo "Mã Câu Hỏi: ".$row['macauhoi'];
                                            echo "<input type='hidden' name='update_id' value=".$row['macauhoi']."></input>";
                                        echo "</div>";

                                        echo "<div class='content'>";
                                            echo "<div>";
                                           $row['noidungcauhoi'] = str_ireplace(array("#include <","#include<"), "#include &lt", $row['noidungcauhoi']);
                                                echo $row['noidungcauhoi'];
                                            echo "</div>";
                                        echo "</div>";

                                        echo "<div class='ans'>";
                                            echo "<div>";
                                            echo "<p>Đáp Án:</p> ";
                                            echo "</div>";
                                            echo "<pre>".$row['noidung']."</pre>";
                                            
                                        echo "</div>";
                                        
                                        echo "<a class='btn' onclick='return confirmUpdate()' "
                                                . "href='update-form.php?update_id=".$row['macauhoi']."' >Cập Nhật";
                                        echo "</a>";
                                        echo "<a class='btn' onclick='return confirmDelete()' "
                                                . "href='del-action.php?del_id=".$row['macauhoi']."' >Xóa";
                                        echo "</a>";
                                        
                                echo "</div></div>";
                            }
                            
                        ?>
                        
                    </div>
                </div>
                
        </div>
    <?php include('./template/block/footer.php');?>
</body>
</html>