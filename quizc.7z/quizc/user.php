<?php
    session_start();
    $title="Quản lý người dùng";
    include ('./template/block/header.php');
    if($_SESSION['admin']==FALSE){
        header("location:login.php");
    }
?>
<body>
    <div class="header" id="header-edit">
        <div class="container">
            <h1><?php if(isset($title)) echo $title; ?></h1>
            <p>Scroll Down</p>
            <img src="./template/Image/arrow-down_icon.png" width="50px" height="50px"></img>
        </div>
    </div>

    <?php include('./template/block/nav.php'); ?>
    
    <div class="main">
        <div class="CSSTableGenerator" >
            <table>
                <caption>Quản lý người dùng</caption>                
                <tr>
                    <td colspan="2">Người dùng</td>
                    <td colspan="2">Cập nhật</td>
                </tr>                
                <?php
                    require_once './connect.php';
                    $query = "SELECT * From canbo ";
                    $result= mysqli_query($conn, $query) or die("SQL USER ERROR");
                    $i=1;
                    while ($row = mysqli_fetch_array($result)) {
                    echo "<tr>"
                            ."<td>"
                                .$i
                            ."</td>"
                            ."<td>"
                                .$row['hoten']
                            ."</td>"
                            ."<td>"
                                ."<a class='button' href='control-user.php?user=".$row['mcb']."'>Cập nhật</a>";
                                if($row['mcb']=='admin'){
                                    echo "<button class='button' disabled='disable'>Xóa</a></button>";
                                }else{
                                    echo "<a class='button' onclick='return confirmDelete()' href='del-user.php?user_del=".$row['mcb']."'>Xóa</a>";
                                }
                       echo "</td>";
                    echo "</tr>";
                    $i++;
                    }
                ?>
            </table>            
        </div>
        <div class="new_user">
            <form class="form-container" id="add_user" action="add-member.php" method="post" accept-charset="utf-8"  onsubmit="return checkForm(this);">
                <div class="form-title"><h2>Người dùng mới</h2></div>
                <div class="form-title">Username</div>
                <input class="form-field" type="text" name="new_id" value="" placeholder="Username" required>
                <p id="error">Id KHÔNG chứa Khoản trắng, dấu phẩy,các ký tự đặc biệt"@ # $ % ^ & *... "</p>
                <div id="error">
                    <p> 
                        <?php
                            if(isset($_SESSION['newIdErr'])){
                                echo "* ".$_SESSION['newIdErr']; 
                                unset($_SESSION['newIdErr']);
                            }
                        ?>
                    </p>
                </div>
                <div class="form-title">Mật khẩu</div>
                <input class="form-field" type="password" name="new_pass" value="" placeholder="Mật khẩu" required>
                <div class="form-title">Họ tên</div>
                <input class="form-field" type="text" name="new_name" value="" placeholder="Họ tên" required>
                <div class="form-title">Email</div>
                <input class="form-field" type="email" name="new_email" value="" placeholder="Email" required>
                <div id="error">
                   <p> 
                        <?php
                            if(isset($_SESSION['newEmailErr'])){
                                echo "* ".$_SESSION['newEmailErr']; 
                                unset($_SESSION['newEmailErr']);
                            }
                        ?>
                    </p>
                </div>
                <div class="form-title">Bộ môn</div>
                <input class="form-field" type="text" name="new_bomon" value="" placeholder="Bộ môn" required>
                <div class="form-title">Số điện thoại</div>
                <input class="form-field" type="phone" name="new_sdt" value="" placeholder="Số điện thoại" required>
                <div class="submit-container">
                <input class="submit-button" type="submit" name="add_user" value="Thêm người dùng" >
                </div>
            </form>            
        </div>

    </div>
    
    <script>
        function checkForm(form)
          {
            if(form.new_id.value == "") {
              alert("Lỗi: Không thể chứa khoản trắng!");
              form.new_id.focus();
              return false;
            }
            re = /^\w+$/;
            if(!re.test(form.new_id.value)) {
              alert("Lỗi: Id chỉ có thể chứa ký tự, số và dấu gạch dưới!");
              form.new_id.focus();
              return false;
            }

            if(form.new_pass.value != ""){
              if(form.new_pass.value.length < 6) {
                alert("Lỗi: Password phải có ít nhất 6 ký tự!");
                form.new_pass.focus();
                return false;
              }
              if(form.new_pass.value == form.new_id.value) {
                alert("Lỗi: Password phải khác username!");
                form.new_pass.focus();
                return false;
              }
              re = /[0-9]/;
              if(!re.test(form.new_pass.value)) {
                alert("Lỗi: password phải chứa ít nhất các số (0-9)!");
                form.new_pass.focus();
                return false;
              }
              re = /[a-z]/;
              if(!re.test(form.new_pass.value)) {
                alert("Lỗi: password phải chứa ít nhất một ký tự thường (a-z)!");
                form.new_pass.focus();
                return false;
              }
              re = /[A-Z]/;
              if(!re.test(form.new_pass.value)) {
                alert("Lỗi: password phải chứa ít nhất một ký tự HOA (A-Z)!");
                form.new_pass.focus();
                return false;
              }
            }
            
          }
    </script>
</body>
</html>